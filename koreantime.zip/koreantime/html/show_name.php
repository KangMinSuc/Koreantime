
<?php
//로그인한 사용자의 이름을 보여주는 파일이다. 자주 깨지니 주의하도록 하자

	$db_host = "localhost"; // 호스트네임(IP 값으로도 가능)
	$db_user = "koreantime"; // 사용자 아이디값(root는 최상위 아이디 이며, 데이터베이스마다 별도 설정 가능합니다)
	$db_passwd = "spark913"; // 사용자 비밀번호
	$db_name = "koreantime"; // 사용할 데이터베이스 이름
    $conn = mysql_connect($db_host,$db_user,$db_passwd);
	$tmp = mysql_select_db($db_name,$conn);
    mysql_query(" set names utf8 ");
	mysql_query("set session character_set_connection=utf8;");
	mysql_query("set session character_set_client=utf8;");
	
	//$current_user = wp_get_current_user();
	//$user = $current_user->user_login; //뭐 복잡한건 아니고 로그인한 사용자의 정보를 디비에서 검색한다.
	$sql = " SELECT * FROM wp_users WHERE 1";
	//$sql = " SELECT meta_key FROM wp_usermeta  WHERE 1";
	$rs = mysql_query($sql,$conn);
	//echo $rs['user_nicename'];
	//$row = mysql_fetch_array($rs);
	while($row = mysql_fetch_array($rs)){
        //if(in_array($row['user_nicename'] , $syn0arr)){
            //fwrite($syn0 , $row['syn'] . "\t" . $row['keyword'] . "\n");
            echo $row['user_nicename'];
            echo ' '."\n";
            //continue;
        //}
    }
	
	//echo $row['ID'];
	//echo $row['user_nicename'];
	//echo $row;
	/*
	$idx = $row['user_id'];
	$sql = " SELECT meta_value FROM wp_usermeta where ( user_id = '$idx' and meta_key = 'usrname_' )";
	$rs = mysql_query($sql,$conn);
	$row = mysql_fetch_array($rs);
	if(is_user_logged_in()) { echo $row['meta_value'];} //이 부분이 로그인한 사용자의 이름을 보여주는 부분이다.
    else{ 
		echo "Please Login";
	}*/
?>